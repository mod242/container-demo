### ICNADMIN

# To run for non icmconfig desktop:
	python icndefaultdriver.py --icnURL `http://ip:9080/navigator/` --icnAdmin `icnadmin` --icnPassd `icnpassword` --ceURL `http://ip:9080/wsi/FNCEWS40MTOM` --objStoreName `OBJECT_STORE` --featureList `browsePane searchPane favorites workPane`  --defaultFeature `browsePane`  --desktopId `DESKTOP_ID` --desktopName `SOME NAME FOR THE DESKTOP` --desktopDesc `SOME DESCRIPTION FOR THE DESKTOP` --applicationName `ANY APPLICATION NAME` --defaultRepo `DEFAULT_REPO_NAME SHOULD BE THE SAME AS THE DISPLAY NAME FOR THE REPO` --connectionPoint `CONNECTION_POINT:ISOLATED_REGION_NUMBER` --osDisplayName DEMODISPLAY

### ex:
	python icndefaultdriver.py --icnURL http://akesoicm4:9080/navigator/ --icnAdmin CEAdmin --icnPassd Genius1 --ceURL http://akesoicm2:9080/wsi/FNCEWS40MTOM --objStoreName DEMO --featureList browsePane searchPane favorites workPane  --defaultFeature browsePane  --desktopId demo --desktopName IBM Demo Container configuration --desktopDesc Default desktop for Demo Container configuration --applicationName IBM Demo Container configuration --defaultRepo DEMODISPLAY --connectionPoint PE_CONN_2:2  --osDisplayName DEMODISPLAY


# To run for icmconfig desktop:
	python icndefaultdriver.py --icnURL `http://ip:9080/navigator/` --icnAdmin `icnadmin` --icnPassd `icnpassword` --ceURL `http://ip:9080/wsi/FNCEWS40MTOM` --objStoreName `OBJECT_STORE` --featureList `ICMContainerConfig`  --defaultFeature `ICMContainerConfig` --pluginLoadList `ICMContainerConfigPlugin` --pluginFilePath `/opt/ibm/icm/config/ICMContainerConfigPlugin.jar` --desktopId `icmconfig` --desktopName `IBM Case Manager Container configuration` --desktopDesc `Default desktop for Case Manager Container configuration` --applicationName `IBM Case Manager Container configuration` --defaultRepo `DEFAULT_REPO_NAME SHOULD BE THE SAME AS THE OBJECT_STORE NAME`

#### ex: 
	python icndefaultdriver.py --icnURL http://akesoicm4:9080/navigator/ --icnAdmin CEAdmin --icnPassd Genius1 --ceURL http://akesoicm2:9080/wsi/FNCEWS40MTOM --objStoreName DESIGN --featureList ICMContainerConfig  --defaultFeature ICMContainerConfig --pluginLoadList ICMContainerConfigPlugin --pluginFilePath /opt/ibm/icm/config/ICMContainerConfigPlugin.jar --desktopId icmconfig --desktopName IBM Case Manager Container configuration --desktopDesc Default desktop for Case Manager Container configuration --applicationName IBM Case Manager Container configuration --defaultRepo DESIGN
