#!/bin/bash
#
# Licensed Materials - Property of IBM
# 5747-SM3
# (c) Copyright IBM Corp. 2017,2018  All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
echo "=========================================="
echo "Begin ending actions"
filename=$ScriptsDir/"status.log"
if [[ $ScriptsDir = "" ]]; then
	source ./d_utils.sh
	echo $ScriptsDir
fi

function stopJDKContainer() {
        echo "Stop JDK docker container now..."
        containerID=`docker ps -a -q --filter name=$JDK_CONTAINER_NAME$`
        if [ "$containerID" != "" ]; then
                result=$(docker stop $containerID)
        fi
        if [[ "" = $result ]]; then
          echo "$JDK_CONTAINER_NAME container is still running, you can use command 'docker stop $JDK_CONTAINER_NAME' to stop it if you want."
          echo "Stop it won't affect your IBM Content foundation environment, and can save some resource of your host."
		else
			echo "JDK container '$JDK_CONTAINER_NAME' stopped successfully."
        fi
}

function urlOutput(){
	echo -e "\033[36m*************************************************************
The script finished successfully, now you can visit your application by below links:
IBM Content Platform Engine: http://$HOST_NAME:9080/acce   P8Admin/<GLOBAL_PASSWORD>
IBM Content Navigator: http://$HOST_NAME:9081/navigator    P8Admin/<GLOBAL_PASSWORD>
*************************************************************\033[0m"
}

stopJDKContainer
urlOutput
